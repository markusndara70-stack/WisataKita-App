package tentang

import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.browser.customtabs.CustomTabsIntent
import com.lauwba.wisatakita.databinding.FragmentTentangBinding

class TentangFragment : Fragment() {

    // 1. Deklarasi variable binding
    private var _binding: FragmentTentangBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // 2. Inflate layout dengan view binding
        _binding = FragmentTentangBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 4. Set action click untuk setiap TextView sosial media
        binding.facebook.setOnClickListener {
            openBrowser("https://www.facebook.com/wildan_ibnu_s")
        }

        binding.telegram.setOnClickListener {
            openBrowser("https://t.me/wildan")
        }

        binding.instagram.setOnClickListener {
            openBrowser("https://instagram.com/wildanibnu_s")
        }
    }

    // 3. Function untuk membuka browser menggunakan Chrome Custom Tabs
    private fun openBrowser(url: String?) {
        url?.let {
            val builder = CustomTabsIntent.Builder()
            val customTabsIntent = builder.build()
            customTabsIntent.launchUrl(requireContext(), Uri.parse(it))
        }
    }

    // 5. Hapus binding saat view dihancurkan
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}