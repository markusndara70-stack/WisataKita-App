package com.lauwba.wisatakita

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.lauwba.wisatakita.databinding.ActivityMainBinding
import destinasi.DestinasiFragment
import portal.PortalFragment
import tentang.TentangFragment
import galeri.GaleriFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Load fragment awal
        this.changeFragment(DestinasiFragment())

        // Setup BottomNavigationView
        binding.bottomMenu.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.portal -> {
                    this.changeFragment(PortalFragment())
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.destinasi -> {
                    this.changeFragment(DestinasiFragment())
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.galeri -> {
                    this.changeFragment(GaleriFragment())
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.tentang -> {
                    this.changeFragment(TentangFragment())
                    return@setOnNavigationItemSelectedListener true
                }
            }
            return@setOnNavigationItemSelectedListener false
        }
    }

    private fun changeFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, fragment)
            .commit()
    }
}
