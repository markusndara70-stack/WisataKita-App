package destinasi

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.lauwba.wisatakita.databinding.ItemDestinationBinding

class DestinasiAdapter(
    private val listDestinasi: List<Destinasi>,
    private val onClickListener: (Destinasi) -> Unit
) : RecyclerView.Adapter<DestinasiAdapter.ViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val binding = ItemDestinationBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = listDestinasi.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(listDestinasi[position])
    }

    inner class ViewHolder(
        private val binding: ItemDestinationBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(destinasi: Destinasi) {
            binding.namaDestinasi.text = destinasi.namaDestinasi
            binding.location.text = destinasi.location
            binding.rating.text = destinasi.rating.toString()

            Glide.with(binding.root.context)
                .load(destinasi.fotoDestinasi)
                .into(binding.destinasiImageItem)

            binding.root.setOnClickListener {
                onClickListener(destinasi)
            }

            binding.viewOnDetail.setOnClickListener {
                onClickListener(destinasi)
            }
        }
    }
}