package destinasi

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.*
import kotlin.math.abs
import androidx.fragment.app.Fragment
import com.google.android.gms.maps.model.LatLng
import com.lauwba.wisatakita.databinding.FragmentDestinasiBinding

class DestinasiFragment : Fragment() {

    private var _binding: FragmentDestinasiBinding? = null
    private val binding get() = _binding!!

    // URL gambar telah diperbaiki (dihilangkan spasi dan karakter aneh)
    private val destinationImage = arrayListOf(
        "https://lh3.googleusercontent.com/p/AF1QipMSvn-2Dq2YjTdMbzLqk_M7oB6vKZ7Z-QfYpgbB=s680-w680-h510",
        "https://lh5.googleusercontent.com/p/AF1QipMEosqi0fvW7a88GROmk874HFLhwhT_z1RphPi=w1000-h780-k-no",
        "https://lh5.googleusercontent.com/p/AF1QipNzTZjNeln6wUrc1sWk1EZCGMRQhDyU3jxHY-uw=w1000-h780-k-no",
        "https://lh5.googleusercontent.com/p/AF1QipPsmfiRY32YKp80kaA-OMq8E8u9agDh9ZnUcDtq=w1000-h780-k-no",
        "https://lh5.googleusercontent.com/p/AF1QipMYljw04dYe4vIo27L0JrWo0lILu8UfwjnzLzYr=w1000-h780-k-no",
        "https://lh5.googleusercontent.com/p/AF1QipNkQJXDmUSTn70kv5X3gskvrUgJol1FT4UkyhYD=w1000-h788-k-no",
        "https://lh5.googleusercontent.com/p/AF1QipPhIc06sZYJIp423XjsgxdQEJv5X5mgEouJ2LHF=w1000-h788-k-no",
        "https://lh5.googleusercontent.com/p/AF1QipPknoGMr9y7hALXLKQZj119UsJ00020-tazF3R=w1156-h780-k-no",
        "https://lh5.googleusercontent.com/p/AF1QipPA2P3xj2NgPsA20qrcZ4DURwynFDkVXK6txTg=w1156-h780-k-no",
        "https://lh5.googleusercontent.com/p/AF1QipNzLkzvZR9REtZNTgod-NAXIN5nLojMpGKny73=w1150-h780-k-no",
        "https://lh5.googleusercontent.com/p/AF1QipM2xZ00Lys8P6Kd1nXA2jTqyNba5_A13y1CAbnB=w1150-h788-k-no",
        "https://lh5.googleusercontent.com/p/AF1QipO5H-Qb-Eh25PAF4fBaenGETqMtQvMVPnQ30-w=w1158-h788-k-no",
        "https://lh5.googleusercontent.com/p/AF1QipOiNuhhorifzTVDuPha9QxigQb-CFXPAEAZMeb=w1156-h780-k-no",
        "https://lh5.googleusercontent.com/p/AF1QipNbnCnj1y_ZPaF188N9a0oXgleAaHk6v6TtMVh=w1150-h780-k-no"
    )

    private val destinationName = arrayListOf(
        "Candi Prambanan", "Taman Sari", "Tugu Jogja", "Taman Nasional Gunung Merapi",
        "Yogyakarta International Airport", "Pantai Parangtritis", "Air Terjun Sri Gethuk",
        "Pantai Indrayanti", "Pantai Pok Tunggal", "Jalan Malioboro", "Pasar Beringharjo",
        "Ratu Boko", "Kebun Buah Mangunan", "Hutan Mangrove Wana Tirta"
    )

    private val destinationLocation = arrayListOf(
        "Sleman", "Kota Yogyakarta", "Kota Yogyakarta", "Sleman", "Kulon Progo",
        "Bantul", "Gunung Kidul", "Gunung Kidul", "Gunung Kidul", "Kota Yogyakarta",
        "Kota Yogyakarta", "Sleman", "Bantul", "Kulon Progo"
    )

    private val destinationLatLng = arrayListOf(
        LatLng(-7.7520211, 110.4925099), LatLng(-7.809798, 110.359054),
        LatLng(-7.7828609, 110.3583181), LatLng(-7.5407175, 110.4457241),
        LatLng(-7.900302, 110.0569203), LatLng(-8.0261393, 110.3351046),
        LatLng(-7.9428521, 110.4871372), LatLng(-8.1507833, 110.6103773),
        LatLng(-8.1554992, 110.6128602), LatLng(-7.7926306, 110.3658442),
        LatLng(-7.798789, 110.3652543), LatLng(-7.7705363, 110.487227),
        LatLng(-7.9413665, 110.4225458), LatLng(-7.89485, 110.0209858)
    )

    private val destinationRating = arrayListOf(
        4.5, 4.6, 4.8, 4.4, 4.6, 4.5, 4.4, 4.5, 4.6, 4.7, 4.5, 4.6, 4.6, 4.1
    )

    private val destinationDescription = arrayListOf(
        "Candi Prambanan adalah bangunan candi bercorak agama Hindu terbesar di Indonesia yang dibangun pada abad ke-9 Masehi.",
        "Taman Sari adalah situs bekas taman atau kebun istana Keraton Ngayogyakarta Hadiningrat yang terletak di pusat kota Yogyakarta.",
        "Tugu Yogyakarta adalah sebuah tugu atau monumen yang sering dipakai sebagai simbol atau lambang dari Kota Yogyakarta.",
        "Taman Nasional Gunung Merapi adalah sebuah taman nasional yang terletak di Jawa bagian tengah, Indonesia dengan gunung berapi aktif Merapi.",
        "Bandar Udara Internasional Yogyakarta (YIA) adalah bandar udara yang terletak di Kulon Progo, Daerah Istimewa Yogyakarta.",
        "Pantai Parangtritis adalah tempat wisata yang terletak di Kabupaten Bantul dengan pemandangan yang indah dan ombak yang besar.",
        "Air Terjun Sri Gethuk merupakan salah satu objek wisata alam yang terletak di Gunungkidul dengan keindahan air terjun alami.",
        "Pantai kecil berpasir putih yang dikelilingi pepohonan dan bebatuan besar yang cocok untuk bersantai dan berenang.",
        "Pantai pasir putih yang dikelilingi tebing & pepohonan, dengan pohon ikonis yang menjadi spot foto favorit.",
        "Jalan Malioboro adalah salah satu kawasan jalan dari tiga jalan di Kota Yogyakarta yang terkenal sebagai pusat oleh-oleh.",
        "Pasar Beringharjo menjadi sebuah bagian dari Malioboro yang sayang untuk dilewatkan dengan berbagai macam kerajinan dan kuliner tradisional.",
        "Ratu Boko adalah situs purbakala yang merupakan kompleks sejumlah sisa bangunan yang terletak di Kabupaten Sleman.",
        "Kebun buah di puncak bukit yang menawan dengan beragam pohon buah dan pemandangan sunset yang indah.",
        "Tanaman Mangrove yang hanya bisa tumbuh di muara sungai, perlu dijaga dan dilestarikan untuk ekosistem pesisir."
    )

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDestinasiBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val listDestinasi = arrayListOf<Destinasi>()
        destinationImage.mapIndexed { index, s ->
            val destinasi = Destinasi(
                destinationName[index],
                destinationRating[index],
                s,
                destinationLatLng[index],
                destinationLocation[index],
                destinationDescription[index]
            )
            listDestinasi.add(destinasi)
        }

        val adapter = DestinasiAdapter(listDestinasi) {
            val detailActivity = Intent(requireActivity(), DetailActivity::class.java)
            detailActivity.putExtra("lat", it.coordinate.latitude)
            detailActivity.putExtra("lng", it.coordinate.longitude)
            detailActivity.putExtra("fotoDestinasi", it.fotoDestinasi)
            detailActivity.putExtra("rating", it.rating)
            detailActivity.putExtra("namaDestinasi", it.namaDestinasi)
            detailActivity.putExtra("deskripsiDestinasi", it.deskripsiDestinasi)
            detailActivity.putExtra("location", it.location)
            startActivity(detailActivity)
        }

        binding.viewPagerSlider.adapter = adapter
        binding.viewPagerSlider.clipToPadding = false
        binding.viewPagerSlider.clipChildren = false
        binding.viewPagerSlider.offscreenPageLimit = 3
        binding.viewPagerSlider.getChildAt(0).overScrollMode = RecyclerView.OVER_SCROLL_NEVER

        val compositePageTransformer = CompositePageTransformer()
        compositePageTransformer.addTransformer(MarginPageTransformer(20))
        compositePageTransformer.addTransformer { page, position ->
            val r = 1 - abs(position)
            page.scaleY = 0.85f + r * 0.15f
        }
        binding.viewPagerSlider.setPageTransformer(compositePageTransformer)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
