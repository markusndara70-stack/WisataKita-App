package destinasi

import android.R
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.BitmapTransitionOptions.with
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapsInitializer
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.snackbar.Snackbar

class MapsViewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMapsViewBinding
    private var maps: GoogleMap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsViewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Ambil data intent
        val lat = intent.getDoubleExtra("lat", 0.0)
        val lng = intent.getDoubleExtra("lng", 0.0)
        val fotoDestinasi = intent.getStringExtra("fotoDestinasi")
        val rating = intent.getDoubleExtra("rating", 0.0)
        val title = intent.getStringExtra("namaDestinasi")
        val alamat = intent.getStringExtra("location")
        val deskripsi = intent.getStringExtra("deskripsi")

        // Toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = title

        // Set data ke view
        binding.rating.text = rating.toString()
        binding.alamat.text = alamat
        binding.deskripsi.text = deskripsi

        Glide.with(binding.root.this)
            .load(fotoDestinasi)
            .into(binding.fotoDestinasi)

        // MapView
        with(binding.mapView)
        onCreate(savedInstanceState)
        getMapAsync { map ->
            this@MapsViewActivity.maps = map
            MapsInitializer.initialize(this)
            addMarkerToMaps(LatLng(lat, lng), map)
        }

        // Navigasi ke Google Maps
        this.binding.navigate.setOnClickListener {
            try {
                val gmmIntentUri =
                    Uri.parse("google.navigation:q=${lat},${lng}")
                val mapIntent =
                    Intent(Intent.ACTION_VIEW, gmmIntentUri)
                mapIntent.setPackage("com.google.android.apps.maps")
                startActivity(mapIntent)
            } catch (e: ActivityNotFoundException) {
                Snackbar.make(
                    findViewById(R.id.content),
                    "Google Maps tidak terinstall",
                    Snackbar.LENGTH_LONG
                ).setAction("Buka Playstore") {
                    val marketIntent = Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.maps")
                    )
                    startActivity(Intent.createChooser(marketIntent, "Lanjutkan..."))
                }.show()
            }
        }
    }

    private fun getMapAsync(function: Any) {}

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menu?.add(0, 0, 0, "Type Normal")
        menu?.add(0, 1, 0, "Type Terrain")
        menu?.add(0, 2, 0, "Type Satellite")
        menu?.add(0, 3, 0, "Type Hybrid")
        return super.onCreateOptionsMenu(menu)
    }

    override fun onResume() {
        binding.mapView.onResume()
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
        binding.mapView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.mapView.onDestroy()
    }

    private fun addMarkerToMaps(
        latLng: LatLng,
        maps: GoogleMap
    ) {
        maps.addMarker(MarkerOptions().position(latLng))
        maps.animateCamera(
            CameraUpdateFactory.newLatLngZoom(latLng, 15f)
        )
    }
}

annotation class ActivityMapsViewBinding {
    val fotoDestinasi: ImageView
}
