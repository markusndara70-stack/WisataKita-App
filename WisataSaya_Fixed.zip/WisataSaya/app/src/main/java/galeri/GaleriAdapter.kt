package galeri

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.lauwba.wisatakita.R
import com.lauwba.wisatakita.databinding.ItemGaleriAdapterBinding

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [GaleriAdapter.newInstance] factory method to
 * create an instance of this fragment.
 */
class GaleriAdapter(
    private val listImage: Array<String>,
    private val onImageClick: (Array<String>, Int) -> Unit
) : RecyclerView.Adapter<GaleriAdapter.ViewHolder>() {

    inner class ViewHolder(
        private val binding: ItemGaleriAdapterBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(url: String, position: Int) {
            Glide.with(binding.root.context)
                .load(url)
                .into(binding.imageItem)

            binding.imageItem.setOnClickListener {
                onImageClick(listImage, position)
            }
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val binding = ItemGaleriAdapterBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return listImage.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(listImage[position], position)
    }
}